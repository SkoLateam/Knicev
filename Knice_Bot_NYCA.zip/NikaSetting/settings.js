// Module
const fs = require('fs')
//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6285177460534'] //Own Number
global.developer = "NYCA" //Dev Name
global.botname = "Knice" //Bot Name
global.version = "1.0.0" //Version Bot
//Sticker Settings
global.packname = "Sticker By" //Pack Name 
global.author = "NYCA" // Author
//Social Media Settings
global.ytube = "https://youtube.com/@barzhost"
global.ttok = ""
global.igram = "https://instagram.com/@kangokep"
global.chtele = ""
global.tgram = "https://t.me/Yamaguchihost"
//Bug Name Settings
global.bak = {
Ios: " \n? ",
Andro: "\n?", 
Crash: " ",
Freeze: "",
Ui: ""
}
//System Bot Settings
global.prefa = ['','!','.',',','\n'] // Prefix // Not Change
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
